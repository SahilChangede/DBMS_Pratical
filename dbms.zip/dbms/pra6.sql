create or replace procedure grade_proc1(rollno in number,marks in number,grad out varchar2)
is
begin
if marks<=1500 and marks>=990 then
grad:='distinction';
elsif marks<=989 and marks>=900 then 
grad:='1st class';
elsif marks<=899 and marks>=825 then 
grad:='2nd class';
else
grad:='fail';
end if;
end;
