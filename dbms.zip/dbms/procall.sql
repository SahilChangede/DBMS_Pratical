declare
r int;
g varchar(20);
m int;
begin
r:=&r;
select rollno,marks into r,m from stud_mark where rollno=r;
grade_proc2(r,m,g);
dbms_output.put_line(g);
end;
